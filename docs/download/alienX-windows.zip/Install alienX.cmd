@echo off
REM Installs alienX into %USERPROFILE%\alienX and opens it. Run it again any time to update.
REM It runs alienX's install script, which you can read first at
REM https://github.com/Dibakar01/alienx/blob/main/install.ps1
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://raw.githubusercontent.com/Dibakar01/alienx/main/install.ps1 | iex"
if errorlevel 1 (
  echo.
  echo Something went wrong ^(see above^).
  pause
  exit /b 1
)
