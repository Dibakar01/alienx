#!/usr/bin/env bash
# Installs alienX into ~/alienX and opens it. Run it again any time to update.
# It runs alienX's install script, which you can read first at
# https://github.com/Dibakar01/alienx/blob/main/install.sh
set -o pipefail
curl -fsSL https://raw.githubusercontent.com/Dibakar01/alienx/main/install.sh | bash ||
  { echo; read -r -n1 -p "Something went wrong (see above). Press any key to close."; exit 1; }
